# cs4280_nbastats

need following libraries installed:
pip install pymongo
pip install flask
pip install flask-pymongo